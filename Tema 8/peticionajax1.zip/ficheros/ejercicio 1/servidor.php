<?php

	echo "La fecha de nacimiento ". $_POST['fecha_nacimiento'].	" NO es válida";
	echo "<br>";
	echo "El código postal ". $_POST['codigo_postal']." SI es válido";
	echo "<br>";
	echo "El teléfono ".$_POST['telefono']." NO es válido";

?>